import re

def detect_bias(parsed_resume):
    issues = []

    # Gender detection from pronouns (basic heuristic)
    if re.search(r'\b(he/him|she/her)\b', parsed_resume.get("resume_text", "").lower()):
        issues.append("Gender-identifying pronouns found.")

    # Age detection from graduation year
    education_text = parsed_resume.get("education", "")
    year_match = re.search(r'\b(19|20)\d{2}\b', education_text)
    if year_match:
        issues.append("Graduation year may reveal age.")

    # Nationality hint detection from location or name (very basic)
    if parsed_resume.get("location") and parsed_resume["location"].lower() not in ["remote", "n/a"]:
        issues.append("Candidate location may introduce nationality bias.")

    return issues
