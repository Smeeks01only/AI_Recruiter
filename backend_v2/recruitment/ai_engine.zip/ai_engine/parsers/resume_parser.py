# ai_engine/parsers/resume_parser.py

import re
import PyPDF2
import spacy



# Example skill keywords (you can expand this list)
SKILLS_DB = [
    "python", "java", "c++", "sql", "machine learning", "data analysis",
    "django", "react", "excel", "communication", "project management"
]

def extract_text_from_pdf(file_path):
    text = ""
    with open(file_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            text += page.extract_text() or ""
    return text

def extract_email(text):
    match = re.search(r'[\w\.-]+@[\w\.-]+', text)
    return match.group(0) if match else None

def extract_phone(text):
    match = re.search(r'\+?\d[\d\-\s]{8,}\d', text)
    return match.group(0) if match else None

def extract_name(text):
    lines = text.strip().split("\n")
    if lines:
        return lines[0].strip()  # naive approach
    return "Unknown"

def extract_skills(text):
    skills_found = []
    text_lower = text.lower()
    for skill in SKILLS_DB:
        if skill.lower() in text_lower:
            skills_found.append(skill)
    return list(set(skills_found))

def parse_resume(file_path):
    text = extract_text_from_pdf(file_path)
    return {
        "name": extract_name(text),
        "email": extract_email(text),
        "phone": extract_phone(text),
        "skills": extract_skills(text)
    }
