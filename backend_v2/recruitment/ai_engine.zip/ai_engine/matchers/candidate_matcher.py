from ai_engine.explainability.explainability import generate_explanation
from ai_engine.bias_detection.bias_detector import detect_bias

def match_candidate_to_job(parsed_resume, job_data):
    score = 0.0
    details = {}

    #Skills Matching
    resume_skills = set(skill.lower() for skill in parsed_resume.get("skills", []))
    required_skills = set(skill.lower() for skill in job_data.get("required_skills", []))
    matched_skills = resume_skills & required_skills
    skill_score = len(matched_skills) / len(required_skills) if required_skills else 0
    score += skill_score * 0.6
    details["skills"] = {
        "matched": list(matched_skills),
        "score": round(skill_score * 100, 2)
    }

    #Education Matching
    education_score = 1.0 if job_data.get("preferred_education", "").lower() in parsed_resume.get("education", "").lower() else 0.0
    score += education_score * 0.2
    details["education"] = {
        "matched": job_data.get("preferred_education"),
        "score": round(education_score * 100, 2)
    }

    #Title Matching
    title_score = 0.0
    for title in job_data.get("preferred_titles", []):
        if title.lower() in parsed_resume.get("experience_titles", "").lower():
            title_score = 1.0
            break
    score += title_score * 0.2
    details["titles"] = {
        "matched": title_score > 0,
        "score": round(title_score * 100, 2)
    }
     
    explanation = generate_explanation(parsed_resume, job_data, details)
    bias_flags = detect_bias(parsed_resume)

    return {
        "match_score": round(score * 100, 2),
        "details": details,
        "explanation": explanation,
        "bias_flags": bias_flags
    }
