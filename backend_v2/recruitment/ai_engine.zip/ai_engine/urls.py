from django.urls import path
from .views import explain_job_matches

urlpatterns = [
    path('job/<int:job_id>/explanations/', explain_job_matches, name='explain_job_matches'),
]
