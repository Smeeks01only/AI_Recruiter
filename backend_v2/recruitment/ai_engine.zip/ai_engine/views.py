from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from applications.models import Application
from jobs.models import Job
from ai_engine.parsers.resume_parser import parse_resume
from ai_engine.matchers.candidate_matcher import match_candidate_to_job


@api_view(['GET'])
@permission_classes([IsAuthenticated])  # Optionally: add IsHRUser
def explain_job_matches(request, job_id):
    try:
        job = Job.objects.get(pk=job_id)
    except Job.DoesNotExist:
        return Response({"error": "Job not found"}, status=404)

    applications = Application.objects.filter(job=job)
    results = []

    for app in applications:
        if not app.resume:
            continue

        parsed_resume = parse_resume(app.resume.path)

        job_data = {
            "required_skills": job.required_skills or [],
            "preferred_education": job.preferred_education or "",
            "preferred_titles": job.preferred_titles or []
        }

        match_result = match_candidate_to_job(parsed_resume, job_data)

        results.append({
            "application_id": app.id,
            "candidate_name": parsed_resume.get("name"),
            "match_score": match_result["match_score"],
            "details": match_result["details"],
            "explanation": match_result["explanation"],
            "bias_flags": match_result["bias_flags"],
        })

    return Response(results)
