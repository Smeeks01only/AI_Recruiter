# ai_engine/explainability.py

def generate_explanation(parsed_resume, job_data, match_details):
    explanation = []

    # Skills 
    matched_skills = match_details["skills"]["matched"]
    required_skills = set(skill.lower() for skill in job_data.get("required_skills", []))
    missing_skills = required_skills - set(matched_skills)

    if missing_skills:
        explanation.append(f"Missing required skills: {', '.join(sorted(missing_skills))}.")
    else:
        explanation.append("All required skills matched.")

    # Education
    education_score = match_details["education"]["score"]
    if education_score > 0:
        explanation.append("Meets preferred education criteria.")
    else:
        explanation.append("Does not meet preferred education criteria.")

    # Titles
    title_score = match_details["titles"]["score"]
    if title_score > 0:
        explanation.append("Has relevant job title experience.")
    else:
        explanation.append("Lacks preferred job title experience.")

    return explanation

